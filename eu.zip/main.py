from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import os
from joblib import load

app = FastAPI()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

pickle_file_path = os.path.join(BASE_DIR, "models", "bmi_classifier.pkl")

# 정적 파일 경로 설정
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR,"static")), name="static")

# 템플릿 파일 경로 설정
templates = Jinja2Templates(directory=os.path.join(BASE_DIR,"templates"))



#=====================================================================================================================
#메인메뉴 설정
@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    # user_authenticated = False  # 여기에 사용자 인증 로직 구현
    # posts = [...]  # 데이터베이스에서 포스트 목록을 가져와야 함
    return templates.TemplateResponse("index.html", {
        "request": request,
        # "user_authenticated": user_authenticated,
        # "posts": posts
    })

@app.get("/blog_list", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("blog_list.html", {
        "request": request,
    })

@app.get("/products_list", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("products_list.html", {
        "request": request,
    })

@app.get("/about", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("about.html", {
        "request": request,
    })





#=====================================================================================================================
#블로그
#1. blog1 = 체질량(BMI) 지수 계산기


@app.get("/blog1", response_class=HTMLResponse)
async def read_project1(request: Request):
    return templates.TemplateResponse("blog1.html", {
        "request": request,
    })


@app.get("/blog2", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog2.html", {
        "request": request,
    })

@app.get("/blog3", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog3.html", {
        "request": request,
    })

@app.get("/blog4", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog4.html", {
        "request": request,
    })

@app.get("/blog5", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog5.html", {
        "request": request,
    })

@app.get("/blog6", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog6.html", {
        "request": request,
    })

@app.get("/blog7", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog7.html", {
        "request": request,
    })

@app.get("/blog8", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog8.html", {
        "request": request,
    })

@app.get("/blog9", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog9.html", {
        "request": request,
    })

@app.get("/blog10", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog10.html", {
        "request": request,
    })

@app.get("/blog11", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog11.html", {
        "request": request,
    })

@app.get("/blog12", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog12.html", {
        "request": request,
    })

@app.get("/blog13", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog13.html", {
        "request": request,
    })

@app.get("/blog14", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog14.html", {
        "request": request,
    })

@app.get("/blog15", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog15.html", {
        "request": request,
    })

@app.get("/blog16", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog16.html", {
        "request": request,
    })

@app.get("/blog17", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog17.html", {
        "request": request,
    })

@app.get("/blog18", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog18.html", {
        "request": request,
    })

@app.get("/blog19", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog19.html", {
        "request": request,
    })

@app.get("/blog20", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog20.html", {
        "request": request,
    })

@app.get("/blog21", response_class=HTMLResponse)
async def project2(request: Request):
    return templates.TemplateResponse("blog21.html", {
        "request": request,
    })



#=====================================================================================================================
#프로젝트
#1. project1 = 체질량(BMI) 지수 계산기



#프로젝트1 ============================================>
#저장된 pkl모델 불러오기
pickle_pr1 = open(pickle_file_path, "rb")
# pickle_in = open("models/banknote_classifier.pkl","rb")
classifier = load(pickle_pr1)

# 현재 스크립트의 절대 경로를 얻고, 그 디렉토리의 경로를 사용하여 데이터베이스 파일의 경로를 설정합니다.
db_file = os.path.join(BASE_DIR, "database", "database1.txt")


@app.get("/project1", response_class=HTMLResponse)
async def read_project1(request: Request):
    # user_authenticated = False  # 여기에 사용자 인증 로직 구현
    # posts = [...]  # 데이터베이스에서 포스트 목록을 가져와야 함
    return templates.TemplateResponse("project1.html", {
        "request": request,
        # "user_authenticated": user_authenticated,
        # "posts": posts
    })


@app.post("/project1-result", response_class=HTMLResponse)
async def predict(
        request: Request,
        sex: float = Form(...),
        age: float = Form(...),
        weight: float = Form(...),
        height: float = Form(...),
    ):
    # cm를 m로 변환
    height_m = height / 100

    # BMI 계산
    bmi = weight / (height_m ** 2)

    sex_mode1 = 0
    sex_mode2 = 0

    if sex == 1:
        sex_p = "남성"
        sex_mode1 = 1
    else:
        sex_p = "여성"
        sex_mode2 = 1

    if bmi < 18.5:
        result = "저체중입니다."
    elif 18.5 <= bmi <= 22.9:
        result = "정상입니다."
    elif 23.0 <= bmi <= 24.9:
        result = "과체중입니다."
    elif 25.0 <= bmi <= 29.9:
        result = "경도비만입니다."
    elif bmi >= 30.0:
        result = "고도비만입니다."

    # 입력받은 데이터를 txt 파일에 저장
    with open(db_file, mode='a') as file:
        file.write(f"{sex}, {age}, {height}, {weight}\n")

    prediction = classifier.predict([[height, weight, sex_mode1, sex_mode2]])

    if prediction == "Extremely Weak":
        prediction_model = "매우 허약합니다. <br><br>의학적 평가: 매우 낮은 BMI는 영양실조, 뼈의 약화, 면역 체계 저하 및 기타 건강 문제를 일으킬 수 있습니다. 전문가에게 상담을 받아 원인을 파악하는 것이 중요합니다.<br>영양 섭취: 영양 밀도가 높은 식사를 통해 체중을 늘릴 필요가 있습니다. 특히, 단백질, 건강한 지방, 비타민 및 미네랄을 충분히 섭취해야 합니다.<br>식사 계획: 일반적으로 작은 식사를 자주 하면서 칼로리와 영양소 섭취를 늘리는 것이 도움이 됩니다. <br>이러한 권장 사항은 기본적인 가이드라인이며, 개인의 건강 상태에 따라 달라질 수 있습니다. 모든 변화를 시작하기 전에 의료 전문가와 상의하는 것이 매우 중요합니다."
    elif prediction == "Weak":
        prediction_model = "허약합니다. <br><br>의학적 평가: 정기적인 건강 검진을 통해 영양 부족이나 다른 의학적 문제가 없는지 확인해야 합니다.<br>영양 섭취: 충분한 칼로리와 영양소를 공급하기 위해 균형 잡힌 식사가 필요합니다. 보충제를 사용하기 전에 전문가의 조언을 구하는 것이 좋습니다.<br>생활 방식 변경: 정기적인 운동 루틴을 포함하지만, 과한 운동은 체중 증가를 방해할 수 있으므로 주의해야 합니다. <br>이러한 권장 사항은 기본적인 가이드라인이며, 개인의 건강 상태에 따라 달라질 수 있습니다. 모든 변화를 시작하기 전에 의료 전문가와 상의하는 것이 매우 중요합니다."
    elif prediction == "Normal":
        prediction_model = "보통입니다. <br><br>건강 유지: 정상 범주에 속한다면 현재 체중을 유지하는 것이 목표입니다. 규칙적인 신체 활동과 균형 잡힌 식사를 유지하세요.<br>정기적인 검진: 비록 BMI가 정상 범위에 있다 하더라도, 정기적인 건강 검진을 통해 심혈관 건강, 혈압 및 혈당 수치 등을 모니터링하는 것이 중요합니다. <br>이러한 권장 사항은 기본적인 가이드라인이며, 개인의 건강 상태에 따라 달라질 수 있습니다. 모든 변화를 시작하기 전에 의료 전문가와 상의하는 것이 매우 중요합니다."
    elif prediction == "Overweight":
        prediction_model = "과체중입니다. <br><br>체중 관리: 체중을 줄이기 위해 적당한 신체 활동을 늘리고, 칼로리 섭취를 감소시키는 것이 권장됩니다.<br>식단 조절: 가공 식품과 고칼로리 음식의 섭취를 줄이고, 신선한 과일, 채소, 통곡물, 단백질을 더 많이 섭취하도록 합니다.<br>생활 습관: 건강한 체중 감량을 위한 장기적인 생활 습관 변화에 집중해야 합니다. <br>이러한 권장 사항은 기본적인 가이드라인이며, 개인의 건강 상태에 따라 달라질 수 있습니다. 모든 변화를 시작하기 전에 의료 전문가와 상의하는 것이 매우 중요합니다."
    elif prediction == " Obesity":
        prediction_model = "비만입니다. <br><br>전문가 상담: 의사나 영양사와 상의하여 체중 감량을 위한 개인화된 계획을 세우는 것이 필요합니다.<br>체중 감량 프로그램: 건강한 식단과 규칙적인 운동 루틴을 통해 체중 감량을 시작해야 합니다.<br>건강 모니터링: 고혈압, 당뇨병, 심장 질환 등 비만과 관련된 건강 문제를 정기적으로 검사하고 관리해야 합니다. <br>이러한 권장 사항은 기본적인 가이드라인이며, 개인의 건강 상태에 따라 달라질 수 있습니다. 모든 변화를 시작하기 전에 의료 전문가와 상의하는 것이 매우 중요합니다."
    elif prediction == "Extreme Obesity":
        prediction_model = "극도의 비만입니다. <br><br>의학적 평가: 고도 비만은 여러 건강 문제의 위험을 증가시킵니다. 의사의 지속적인 모니터링이 필요합니다.<br>중재적 접근: 때로는 체중 감량 수술이나 의학적으로 감독된 체중 감량 프로그램이 필요할 수 있습니다.<br>지원 체계: 체중 감량 과정에서 정서적 지원을 받는 것이 중요합니다. 그룹 상담이나 온라인 지원 그룹의 도움을 받을 수 있습니다. <br>이러한 권장 사항은 기본적인 가이드라인이며, 개인의 건강 상태에 따라 달라질 수 있습니다. 모든 변화를 시작하기 전에 의료 전문가와 상의하는 것이 매우 중요합니다."
    else:
        prediction_model = "측정 오류."

    prediction_text = f"<br>성별: {sex_p}<br> 나이: {age}세<br> 키: {height}cm<br> 몸무게: {weight}kg<br> 계산된 BMI: {bmi:.2f}<br> 정량적 계산결과(수치적 단순계산): {result}<br> AI모델 예측결과(실제 검사결과에 의한 정밀계산): {prediction_model}"
    return templates.TemplateResponse("project1-result.html", {"request": request, "prediction": prediction_text})










#프로젝트2 ============================================>
@app.get("/project2", response_class=HTMLResponse)
async def project2(request: Request):

    return templates.TemplateResponse("project2.html", {
        "request": request,
    })

@app.post("/project2-result", response_class=HTMLResponse)
async def predict(
        request: Request,
        first: float = Form(...),
        second: float = Form(...),
        operation: str = Form(...)
    ):

    # 연산에 따른 결과를 계산합니다.
    if operation == 'add':
        result = first + second
        operation_name = '더하기'
    elif operation == 'subtract':
        result = first - second
        operation_name = '빼기'
    elif operation == 'multiply':
        result = first * second
        operation_name = '곱하기'
    elif operation == 'divide':
        result = first / second if second != 0 else '무한대'  # 0으로 나누기 방지
        operation_name = '나누기'
    else:
        result = '알 수 없는 연산'
        operation_name = '알 수 없음'

    prediction_text2 = f"{operation_name} 결과는 {result} 입니다."
    return templates.TemplateResponse("project2-result.html", {"request": request, "prediction": prediction_text2})




#=====================================================================================================================



